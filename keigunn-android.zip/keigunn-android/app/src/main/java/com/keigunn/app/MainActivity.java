package com.keigunn.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {

    private WebView webView;
    private ScrollView modeScreen;
    private FrameLayout webContainer;
    private String currentMode = null;
    private WebViewAssetLoader assetLoader;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 전체화면
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.parseColor("#0f2744"));
        }

        // 루트 레이아웃
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0f172a"));
        setContentView(root);

        // ─── 모드 선택 화면 ───
        modeScreen = buildModeScreen();
        root.addView(modeScreen, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // ─── WebView 컨테이너 ───
        webContainer = new FrameLayout(this);
        webContainer.setVisibility(View.GONE);
        root.addView(webContainer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // WebView
        webView = new WebView(this);
        webContainer.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // Asset Loader: assets/ → https://appassets.androidplatform.net/assets/
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);

        webView.addJavascriptInterface(new AppBridge(), "AndroidApp");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                WebResourceResponse res = assetLoader.shouldInterceptRequest(req.getUrl());
                return res != null ? res : super.shouldInterceptRequest(v, req);
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String url = req.getUrl().toString();
                return !url.contains("appassets.androidplatform.net");
            }
        });

        // 이전 모드 복원 (없으면 선택 화면 유지)
        String saved = getSharedPreferences("keigunn", MODE_PRIVATE).getString("mode", null);
        if (saved != null) launchMode(saved);
    }

    // ──────────────────────────────────────────────────────
    //  모드 선택 화면
    // ──────────────────────────────────────────────────────
    private ScrollView buildModeScreen() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0f172a"));
        sv.setFillViewport(true);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setGravity(Gravity.CENTER_HORIZONTAL);
        inner.setPadding(dp(28), dp(64), dp(28), dp(40));

        // 로고 이모지
        TextView logo = new TextView(this);
        logo.setText("⚖️");
        logo.setTextSize(60);
        logo.setGravity(Gravity.CENTER);
        inner.addView(logo);

        // 앱 이름
        TextView appName = new TextView(this);
        appName.setText("계근 앱");
        appName.setTextColor(Color.WHITE);
        appName.setTextSize(28);
        appName.setTypeface(null, Typeface.BOLD);
        appName.setGravity(Gravity.CENTER);
        appName.setPadding(0, dp(10), 0, dp(6));
        inner.addView(appName);

        TextView appSub = new TextView(this);
        appSub.setText("사용할 앱을 선택하세요");
        appSub.setTextColor(Color.parseColor("#94a3b8"));
        appSub.setTextSize(13);
        appSub.setGravity(Gravity.CENTER);
        appSub.setPadding(0, 0, 0, dp(44));
        inner.addView(appSub);

        // 기사 앱 카드
        inner.addView(buildAppCard(
                "🚛  기사 앱",
                "입차 · 상차완료 · 출차 계근",
                "#1d4ed8",
                "driver"
        ));

        // 간격
        View gap = new View(this);
        inner.addView(gap, new LinearLayout.LayoutParams(1, dp(16)));

        // 지게차 앱 카드
        inner.addView(buildAppCard(
                "🦺  지게차 앱",
                "상차예정 알림 · 상차완료 관리",
                "#16a34a",
                "forklift"
        ));

        // 하단 버전 텍스트
        TextView ver = new TextView(this);
        ver.setText("계근 앱 v1.0  ·  오프라인 지원");
        ver.setTextColor(Color.parseColor("#475569"));
        ver.setTextSize(11);
        ver.setGravity(Gravity.CENTER);
        ver.setPadding(0, dp(40), 0, 0);
        inner.addView(ver);

        sv.addView(inner);
        return sv;
    }

    private LinearLayout buildAppCard(String title, String subtitle, String color, String mode) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(24), dp(28), dp(24), dp(24));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(18));
        bg.setColor(Color.parseColor(color));
        card.setBackground(bg);

        TextView titleTv = new TextView(this);
        titleTv.setText(title);
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(20);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setGravity(Gravity.CENTER);
        card.addView(titleTv);

        TextView subTv = new TextView(this);
        subTv.setText(subtitle);
        subTv.setTextColor(Color.parseColor("#ffffffcc"));
        subTv.setTextSize(12);
        subTv.setGravity(Gravity.CENTER);
        subTv.setPadding(0, dp(6), 0, dp(16));
        card.addView(subTv);

        TextView btn = new TextView(this);
        btn.setText("앱 열기  →");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(14);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(32), dp(10), dp(32), dp(10));
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setCornerRadius(dp(30));
        btnBg.setColor(Color.parseColor("#00000033"));
        btn.setBackground(btnBg);
        card.addView(btn);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        card.setLayoutParams(lp);

        card.setOnClickListener(v -> launchMode(mode));
        card.setClickable(true);

        return card;
    }

    // ──────────────────────────────────────────────────────
    //  앱 실행
    // ──────────────────────────────────────────────────────
    private void launchMode(String mode) {
        currentMode = mode;
        getSharedPreferences("keigunn", MODE_PRIVATE).edit().putString("mode", mode).apply();

        String url = "driver".equals(mode)
                ? "https://appassets.androidplatform.net/assets/driver.html"
                : "https://appassets.androidplatform.net/assets/forklift.html";

        webView.loadUrl(url);
        modeScreen.setVisibility(View.GONE);
        webContainer.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (webContainer.getVisibility() == View.VISIBLE) {
            if (webView.canGoBack()) {
                webView.goBack();
            } else {
                webContainer.setVisibility(View.GONE);
                modeScreen.setVisibility(View.VISIBLE);
                currentMode = null;
                getSharedPreferences("keigunn", MODE_PRIVATE).edit().remove("mode").apply();
            }
        } else {
            super.onBackPressed();
        }
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ──────────────────────────────────────────────────────
    //  JavaScript ↔ Java 브릿지
    // ──────────────────────────────────────────────────────
    class AppBridge {
        @JavascriptInterface
        public String getMode() { return currentMode != null ? currentMode : ""; }

        @JavascriptInterface
        public void showToast(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void goHome() {
            runOnUiThread(() -> {
                webContainer.setVisibility(View.GONE);
                modeScreen.setVisibility(View.VISIBLE);
                currentMode = null;
                getSharedPreferences("keigunn", MODE_PRIVATE).edit().remove("mode").apply();
            });
        }
    }
}
